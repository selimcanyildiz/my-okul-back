window.addEventListener("message", (event) => {
    if (event.origin !== "https://my-okul-front.vercel.app" || event.data.source !== "selim-front") {
        return; // Güvenlik için yalnızca belirli kaynaktan gelen mesajları kabul et
    }

    if (event.data.action === "login") {
        const { url, username, password, usernameInputId, passwordInputId, loginButtonId } = event.data.data;

        // Background script'e mesaj gönder
        chrome.runtime.sendMessage({
            action: "performLogin",
            data: { url, username, password, usernameInputId, passwordInputId, loginButtonId },
        });
    }
});