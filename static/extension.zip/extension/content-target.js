chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fillAndSubmit") {
        const { username, password, usernameInputId, passwordInputId, loginButtonId } = request.data;

        // Kullanıcı adı ve şifreyi input alanlarına doldur
        const usernameInput = document.getElementById(usernameInputId);
        const passwordInput = document.getElementById(passwordInputId);

        if (usernameInput) usernameInput.value = username;
        if (passwordInput) passwordInput.value = password;

        // Giriş butonuna click event'i simüle et
        const loginButton = document.getElementById(loginButtonId);
        if (loginButton) {
            // Simüle edilen mouse click
            const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            });
            loginButton.dispatchEvent(clickEvent); // Simüle edilen tıklama
        }
    }
});
