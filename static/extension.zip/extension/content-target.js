chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fillAndSubmit") {
        const { username, password, usernameInputId, passwordInputId, loginButtonId } = request.data;
        document.getElementById(usernameInputId).value = username;
        document.getElementById(passwordInputId).value = password;
        // document.getElementById(loginButtonId).click();

        // Button'a click event simüle etme
        const loginButton = document.getElementById(loginButtonId);
        if (loginButton) {
            const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            });
            loginButton.dispatchEvent(clickEvent);
        }
    }
});