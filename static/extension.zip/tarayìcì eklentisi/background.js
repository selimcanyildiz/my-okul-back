chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "performLogin") {
        const { url, username, password, usernameInputId, passwordInputId, loginButtonId } = request.data;

        chrome.tabs.create({ url }, (tab) => {
            chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
                if (tabId === tab.id && changeInfo.status === "complete") {
                    chrome.tabs.sendMessage(tabId, {
                        action: "fillAndSubmit",
                        data: { username, password, usernameInputId, passwordInputId, loginButtonId },
                    });
                    chrome.tabs.onUpdated.removeListener(listener);
                }
            });
        });
    }
});