chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "fillAndSubmit") {
        const { username, password, usernameInputId, passwordInputId, loginButtonId } = request.data;
        document.getElementById(usernameInputId).value = username;
        document.getElementById(passwordInputId).value = password;
        document.getElementById(loginButtonId).click();
    }
});